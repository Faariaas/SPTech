import{
    BrowserRouter,
    Routes,
    Route
} from "react-router-dom"
import Home from "./pages/Home";
import Musicas from "./pages/Musicas";
import { NotFound } from "./pages/NotFound";

function Router () {
    return(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/musicas" element={Musicas()}/>
                <Route path="*" element={NotFound()} />
            </Routes>
        </BrowserRouter>
    )
}

export default Router;