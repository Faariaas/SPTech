import editIcon from "../assets/imagens/edit-icon.png"
import deleteIcon from "../assets/imagens/delete-icon.png"

import capaPadrao from "../assets/imagens/capa.png"
import { useState } from "react";

function CardMusica(props) {

  const [estaEditando, setEstaEditando] = useState(false);
  // exibindo objeto de "musica" recebido como props
  console.log(`${props.musica.id} - Imagem: `, props.musica.imagem);

  const estilo ={
    backgroundImage: `url(${props.musica.imagem ? props.musica.imagem: capaPadrao})`
  }

  // function habilitarEdicao(){
  //   setEstaEditando(true)
  // }

  // function desabilitaEdicao() {
  //   setEstaEditando(false)
  // }

  return (
    <div style={estilo} className="card-music">
      <div className="icons">
        {/* utilizando recursos de imagem como fonte da tag img */}
        <img onClick={() => setEstaEditando(true)} src={editIcon} alt="" />
        <img src={deleteIcon} alt="" />
      </div>
      <div className="info-music">
        <p>
          <strong className="card-title">música: </strong>
          <input
            disabled= {estaEditando === false}
            className={estaEditando ? 'input-music-enable' : 'input-music-disabled'}
            type="text"
            defaultValue={props.musica.titulo} // utilizando atributo "título" do objeto "musica" recebido como props, para exibir como valor padrão da input
          />
        </p>
        <p>
          <strong className="card-title">artista: </strong>
          <input
            disabled= {estaEditando === false}
            className={estaEditando ? 'input-music-enable' : 'input-music-disabled'}
            type="text"
            defaultValue={props.musica.artista} // utilizando atributo "artista" do objeto "musica" recebido como props, para exibir como valor padrão da input
          />
        </p>
        <p>
          <strong className="card-title">gênero: </strong>
          <input
            disabled= {estaEditando === false}
            className={estaEditando ? 'input-music-enable' : 'input-music-disabled'}
            type="text"
            defaultValue={props.musica.genero} // utilizando atributo "genero" do objeto "musica" recebido como props, para exibir como valor padrão da input
          />
        </p>
        <p>
          <strong className="card-title">ano: </strong>
          <input
            disabled= {estaEditando === false}
            className={estaEditando ? 'input-music-enable' : 'input-music-disabled'}
            type="text"
            defaultValue={props.musica.ano} // utilizando atributo "ano" do objeto "musica" recebido como props, para exibir como valor padrão da input
          />
        </p>
        <button className={estaEditando ? 'btn-salvar-enable' : 'btn-salvar-disabled'} onClick={() => setEstaEditando(false)}>Salvar</button>
      </div>
    </div>
  );
}

export default CardMusica;
