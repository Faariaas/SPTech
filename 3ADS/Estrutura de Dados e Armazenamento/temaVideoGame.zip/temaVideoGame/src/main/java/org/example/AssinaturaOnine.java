package org.example;

public interface AssinaturaOnine {
    private int mesesAssinados;

    public void assinarMensalidade
}
