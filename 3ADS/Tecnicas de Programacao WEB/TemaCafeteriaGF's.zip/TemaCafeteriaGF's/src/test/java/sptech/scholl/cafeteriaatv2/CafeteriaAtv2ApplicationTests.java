package sptech.scholl.cafeteriaatv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeteriaAtv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
