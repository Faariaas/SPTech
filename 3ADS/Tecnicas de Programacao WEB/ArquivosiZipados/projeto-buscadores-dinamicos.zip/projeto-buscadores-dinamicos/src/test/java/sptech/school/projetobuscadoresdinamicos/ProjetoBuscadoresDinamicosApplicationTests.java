package sptech.school.projetobuscadoresdinamicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBuscadoresDinamicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
