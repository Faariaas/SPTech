package school.sptech.projetoormads;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoOrmAdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoOrmAdsApplication.class, args);
	}

}
