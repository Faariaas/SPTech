package school.sptech.projetoormads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoOrmAdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
