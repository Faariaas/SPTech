package school.sptech.primeiraapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiraApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
