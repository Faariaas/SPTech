package school.sptech.carro;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CarroInterface extends JpaRepository<Carro, Long> {
}
