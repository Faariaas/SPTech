package school.sptech.filmeAula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmeAulaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmeAulaApplication.class, args);
	}

}
