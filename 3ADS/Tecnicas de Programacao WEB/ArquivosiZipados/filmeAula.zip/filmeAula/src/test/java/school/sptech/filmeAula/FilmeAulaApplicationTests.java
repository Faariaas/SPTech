package school.sptech.filmeAula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmeAulaApplicationTests {

	@Test
	void contextLoads() {
	}

}
