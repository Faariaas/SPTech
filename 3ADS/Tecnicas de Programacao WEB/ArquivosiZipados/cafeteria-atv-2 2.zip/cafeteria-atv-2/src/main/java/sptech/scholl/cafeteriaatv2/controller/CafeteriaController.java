package sptech.scholl.cafeteriaatv2.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import sptech.scholl.cafeteriaatv2.domain.Cliente;
import sptech.scholl.cafeteriaatv2.domain.ClienteDTO;
import sptech.scholl.cafeteriaatv2.domain.Pedido;
import sptech.scholl.cafeteriaatv2.domain.PedidoDTO;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/filmes")
public class CafeteriaController {

    //Obter todos os produtos disponíveis
    @GetMapping("/produtos")
    public List<ProdutoDTO> obterProdutosDisponiveis() {
        List<Produto> produtos = produtoRepository.findByDisponivelTrue();
        return produtos.stream()
                .map(produto -> new ProdutoDTO(produto.getId(), produto.getNome(), produto.getPreco()))
                .collect(Collectors.toList());
    }
    //Criar um novo cliente
    @PostMapping("/clientes")
    public ResponseEntity<ClienteDTO> criarCliente(@RequestBody @Valid CriarClienteDTO criarClienteDTO) {
        Cliente cliente = new Cliente(criarClienteDTO.getNome(), criarClienteDTO.getEmail());
        cliente = clienteRepository.save(cliente);
        ClienteDTO clienteDTO = new ClienteDTO(cliente.getId(), cliente.getNome());
        return ResponseEntity.status(HttpStatus.CREATED).body(clienteDTO);
    }
    //Atualizar os dados de um cliente existente
    @PutMapping("/clientes/{id}")
    public ResponseEntity<ClienteDTO> atualizarCliente(@PathVariable Long id, @RequestBody @Valid AtualizarClienteDTO atualizarClienteDTO) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(id);
        if (clienteOptional.isPresent()) {
            Cliente cliente = clienteOptional.get();
            cliente.setNome(atualizarClienteDTO.getNome());
            cliente.setEmail(atualizarClienteDTO.getEmail());
            cliente = clienteRepository.save(cliente);
            ClienteDTO clienteDTO = new ClienteDTO(cliente.getId(), cliente.getNome());
            return ResponseEntity.ok(clienteDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    //Obter todos os pedidos de um cliente
    @GetMapping("/clientes/{id}/pedidos")
    public List<PedidoDTO> obterPedidosDoCliente(@PathVariable Long id) {
        List<Pedido> pedidos = pedidoRepository.findByClienteId(id);
        return pedidos.stream()
                .map(pedido -> new PedidoDTO(pedido.getId(), pedido.getDescricao()))
                .collect(Collectors.toList());
    }
    //Obter um produto pelo ID
    @GetMapping("/produtos/{id}")
    public ResponseEntity<ProdutoDTO> obterProdutoPorId(@PathVariable Long id) {
        Optional<Produto> produtoOptional = produtoRepository.findById(id);
        if (produtoOptional.isPresent()) {
            Produto produto = produtoOptional.get();
            ProdutoDTO produtoDTO = new ProdutoDTO(produto.getId(), produto.getNome(), produto.getPreco());
            return ResponseEntity.ok(produtoDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    //Criar um novo pedido para um cliente
    @PostMapping("/clientes/{id}/pedidos")
    public ResponseEntity<PedidoDTO> criarPedido(@PathVariable Long id, @RequestBody @Valid CriarPedidoDTO criarPedidoDTO) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(id);
        if (clienteOptional.isPresent()) {
            Cliente cliente = clienteOptional.get();
            Pedido pedido = new Pedido(cliente, criarPedidoDTO.getDescricao(), criarPedidoDTO.getProdutos());
            pedido = pedidoRepository.save(pedido);
            PedidoDTO pedidoDTO = new PedidoDTO(pedido.getId(), pedido.getDescricao());
            return ResponseEntity.status(HttpStatus.CREATED).body(pedidoDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    //deletar um pedido pelo id
    @DeleteMapping("/pedidos/{id}")
    public ResponseEntity<?> deletarPedido(@PathVariable Long id) {
        Optional<Pedido> pedidoOptional = pedidoRepository.findById(id);
        if (!pedidoOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        pedidoRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    //buscar todos os clientes cadastrados:
    @GetMapping("/clientes")
    public ResponseEntity<List<ClienteDTO>> listarClientes() {
        List<Cliente> clientes = clienteRepository.findAll();
        List<ClienteDTO> clientesDTO = clientes.stream()
                .map(cliente -> mapper.map(cliente, ClienteDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok().body(clientesDTO);
    }









}
