package sptech.scholl.cafeteriaatv2.domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class ItemPedidoDTO {
    private Long id;

    @NotNull
    private Long idPedido;

    @NotNull
    private Long idProduto;

    @NotNull
    @Min(1)
    private Integer quantidade;
}
