package sptech.scholl.cafeteriaatv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeteriaAtv2Application {

	public static void main(String[] args) {
		SpringApplication.run(CafeteriaAtv2Application.class, args);
	}

}
