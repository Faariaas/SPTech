package sptech.scholl.cafeteriaatv2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sptech.scholl.cafeteriaatv2.domain.ItemPedido;

@Repository
public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long> {
    @Query("SELECT COUNT(i) FROM ItemPedido i WHERE i.pedido.id = :idPedido")
    int countByPedidoId(@Param("idPedido") Long idPedido);
}
