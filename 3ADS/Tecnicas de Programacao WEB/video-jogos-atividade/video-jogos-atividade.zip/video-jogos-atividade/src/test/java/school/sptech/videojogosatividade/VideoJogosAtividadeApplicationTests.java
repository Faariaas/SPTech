package school.sptech.videojogosatividade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoJogosAtividadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
